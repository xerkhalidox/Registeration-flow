export default (colors = {
  white: '#fff',
  waterBlue: '#159EDA',
  gray: '#A3A3A3',
});
