import React from 'react';
import styled from 'styled-components/native';

const Column = styled.View`
  ${props => props.extendedStyle};
`;

export default Column;
