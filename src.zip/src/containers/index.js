import NewAccountNameContainer from './NewAccountNameContainer';

export {NewAccountNameContainer};
